package electricity.billing.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;

public class Bill_details extends JFrame {
    String meter;
    JLabel heading,meterLabel,meterno,name,nameLabel,month,unit,unittext,totalbill,totalbilltext,status,statustext;
    Choice monthcho;
    JButton pay,back;
    Bill_details(String meter){
        super("Bill Details");
        this.meter = meter;
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        heading = new JLabel("Bill Details");
        heading.setBounds(240,15,200,50);
        heading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(heading);

        JTable table = new JTable();

        try{
            Database d = new Database();
            String query = "select * from Bill where meter_no = '"+meter+"'";
            ResultSet resultSet = d.statement.executeQuery(query);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }
        catch (Exception e){
            e.printStackTrace();
        }
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(0,66,600,434);
        add(sp);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Bill_details("");
    }
}

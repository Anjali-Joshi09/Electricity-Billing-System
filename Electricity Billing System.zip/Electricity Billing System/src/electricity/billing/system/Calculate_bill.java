package electricity.billing.system;

import javax.swing.*;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;

public class Calculate_bill extends JFrame implements ActionListener {
    JLabel bill,meterNo,nametext,name,address,addresstext,unit,month;
    Choice metercho,monthcho;
    JTextField unittext;
    JButton submit,cancel;
    Calculate_bill(){
        super("Calculate Bill");
        setSize(500,420);
        setLocation(385,100);
        setLayout(null);
        getContentPane().setBackground(new Color(202, 172, 246));
        bill = new JLabel("Bill");
        bill.setBounds(220,15,150,50);
        bill.setFont(new Font("Tahoma",Font.BOLD,20));
        add(bill);

        meterNo = new JLabel("Meter Number");
        meterNo.setBounds(100,70,100,50);
        add(meterNo);
        metercho = new Choice();
        try{
            Database d = new Database();
            ResultSet res = d.statement.executeQuery("select * from NewCustomer");
            while(res.next()){
                metercho.add(res.getString("meter_no"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        metercho.setBounds(240,87,150,25);
        add(metercho);

        name = new JLabel("Name");
        name.setBounds(100,110,100,50);
        add(name);
        nametext = new JLabel("");
        nametext.setBounds(240,110,100,50);
        add(nametext);

        address = new JLabel("Address");
        address.setBounds(100,150,100,50);
        add(address);
        addresstext = new JLabel("");
        addresstext.setBounds(240,150,100,50);
        add(addresstext);

        metercho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent i) {
                try{
                    Database d = new Database();
                    ResultSet resultSet = d.statement.executeQuery("select * from NewCustomer where meter_no = '"+metercho.getSelectedItem()+"'");
                    while(resultSet.next()){
                        nametext.setText(resultSet.getString("name"));
                        addresstext.setText(resultSet.getString("address"));
                    }
                }
                catch (Exception ee){
                    ee.printStackTrace();
                }
            }
        });
        unit = new JLabel("Unit Consumed");
        unit.setBounds(100,190,100,50);
        add(unit);
        unittext = new JTextField();
        unittext.setBounds(240,204,150,20);
        add(unittext);

        month = new JLabel("Month");
        month.setBounds(100,230,100,50);
        add(month);
        monthcho = new Choice();
        monthcho.setBounds(240,243,150,25);
        monthcho.add("January");
        monthcho.add("February");
        monthcho.add("March");
        monthcho.add("April");
        monthcho.add("May");
        monthcho.add("June");
        monthcho.add("July");
        monthcho.add("August");
        monthcho.add("September");
        monthcho.add("October");
        monthcho.add("November");
        monthcho.add("December");
        add(monthcho);

        submit = new JButton("Submit");
        submit.setBounds(115,310,100,25);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);

        cancel = new JButton("Cancel");
        cancel.setBounds(265,310,100,25);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        add(cancel);

        setVisible(true);
    }
    public static void main(String[] args) {
        new Calculate_bill();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==submit)
        {
            String smeterno = metercho.getSelectedItem();
            String sunit = unittext.getText();
            String smonth = monthcho.getSelectedItem();
            int totalBill = 0;
            int units = Integer.parseInt(sunit);
            String query = "select * from Tax";
            try{
                Database d = new Database();
                ResultSet resultSet = d.statement.executeQuery(query);
                while(resultSet.next()){
                    totalBill += units * Integer.parseInt(resultSet.getString("cost_per_unit"));
                    totalBill += Integer.parseInt(resultSet.getString("meter_rent"));
                    totalBill += Integer.parseInt(resultSet.getString("service_charge"));
                    totalBill += Integer.parseInt(resultSet.getString("service_tax"));
                    totalBill += Integer.parseInt(resultSet.getString("swacch_bharat_tax"));
                    totalBill += Integer.parseInt(resultSet.getString("fixed_tax"));
                }
            }
            catch (Exception E){
                E.printStackTrace();;
            }
            String query_bill = "insert into Bill value('"+smeterno+"','"+smonth+"','"+sunit+"','"+totalBill+"','Not Paid')";
            try{
                Database d = new Database();
                d.statement.executeUpdate(query_bill);
                JOptionPane.showMessageDialog(null,"Customer Bill updated successfully");
                setVisible(false);
            }
            catch (Exception ee){
                ee.printStackTrace();
            }
        }
        else {
            setVisible(false);
        }
    }
}

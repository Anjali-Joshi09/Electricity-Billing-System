package electricity.billing.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.awt.Image.SCALE_DEFAULT;

public class Main_class extends JFrame implements ActionListener{
    String acctype,meter_pass;
    Main_class(String acctype,String meter_pass)
    {
        this.acctype = acctype;
        this.meter_pass = meter_pass;
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/main.png"));
        Image imageSet = imageIcon.getImage().getScaledInstance(1300,650,SCALE_DEFAULT);
        ImageIcon imageIcon2 = new ImageIcon(imageSet);
        JLabel imageLabel = new JLabel(imageIcon2);
        add(imageLabel);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menu = new JMenu("Menu");
        menu.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem newCustomer = new JMenuItem("New Customer");
        newCustomer.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon customerImage = new ImageIcon(ClassLoader.getSystemResource("icons/newCustomer.png"));
        Image custImage = customerImage.getImage().getScaledInstance(24,24, SCALE_DEFAULT);
        newCustomer.setIcon(new ImageIcon(custImage));
        newCustomer.addActionListener(this);
        menu.add(newCustomer);

        JMenuItem customerDetails = new JMenuItem("Customer Details");
        customerDetails.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon custDetail = new ImageIcon(ClassLoader.getSystemResource("icons/customerDetail.png"));
        Image customerDetail = custDetail.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        customerDetails.setIcon(new ImageIcon(customerDetail));
        customerDetails.addActionListener(this);
        menu.add(customerDetails);

        JMenuItem depositDetails = new JMenuItem("Deposit Details");
        depositDetails.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon depoDetail = new ImageIcon(ClassLoader.getSystemResource("icons/depositDetail.png"));
        Image depositDetail = depoDetail.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        depositDetails.setIcon(new ImageIcon(depositDetail));
        depositDetails.addActionListener(this);
        menu.add(depositDetails);

        JMenuItem calculatebill = new JMenuItem("Calculate Bill");
        calculatebill.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon calculate = new ImageIcon(ClassLoader.getSystemResource("icons/calculateBill.png"));
        Image calculateBill = calculate.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        calculatebill.setIcon(new ImageIcon(calculateBill));
        calculatebill.addActionListener(this);
        menu.add(calculatebill);

        JMenu info = new JMenu("Information");
        info.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem updateinfo = new JMenuItem("Update Information");
        updateinfo.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon update = new ImageIcon(ClassLoader.getSystemResource("icons/update.png"));
        Image updateBill = update.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        updateinfo.setIcon(new ImageIcon(updateBill));
        updateinfo.addActionListener(this);
        info.add(updateinfo);

        JMenuItem viewinfo = new JMenuItem("View Information");
        viewinfo.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon view = new ImageIcon(ClassLoader.getSystemResource("icons/view.png"));
        Image viewInfo = view.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        viewinfo.setIcon(new ImageIcon(viewInfo));
        viewinfo.addActionListener(this);
        info.add(viewinfo);

        JMenu user = new JMenu("User");
        user.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem paybill = new JMenuItem("Pay Bill");
        paybill.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon pay = new ImageIcon(ClassLoader.getSystemResource("icons/pay.png"));
        Image payBill = pay.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        paybill.setIcon(new ImageIcon(payBill));
        paybill.addActionListener(this);
        user.add(paybill);

        JMenuItem billdetails = new JMenuItem("Bill Details");
        billdetails.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon billd = new ImageIcon(ClassLoader.getSystemResource("icons/billDetail.png"));
        Image billDetail = billd.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        billdetails.setIcon(new ImageIcon(billDetail));
        billdetails.addActionListener(this);
        user.add(billdetails);

        JMenu bill = new JMenu("Bill");
        bill.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem generatebill = new JMenuItem("Generate Bill");
        generatebill.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon generate = new ImageIcon(ClassLoader.getSystemResource("icons/generate.png"));
        Image generateBill = generate.getImage().getScaledInstance(20,20,SCALE_DEFAULT);
        generatebill.setIcon(new ImageIcon(generateBill));
        generatebill.addActionListener(this);
        bill.add(generatebill);

        JMenu utility = new JMenu("Utility");
        utility.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem notepad = new JMenuItem("Notepad");
        notepad.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon note = new ImageIcon(ClassLoader.getSystemResource("icons/notepad.png"));
        Image notePad = note.getImage().getScaledInstance(20,20,SCALE_DEFAULT);
        notepad.setIcon(new ImageIcon(notePad));
        notepad.addActionListener(this);
        utility.add(notepad);

        JMenuItem calculator = new JMenuItem("Calculator");
        calculator.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon calcul = new ImageIcon(ClassLoader.getSystemResource("icons/calculator.png"));
        Image calcula = calcul.getImage().getScaledInstance(20,20,SCALE_DEFAULT);
        calculator.setIcon(new ImageIcon(calcula));
        calculator.addActionListener(this);
        utility.add(calculator);

        JMenu exit = new JMenu("Exit");
        exit.setFont(new Font("serif",Font.PLAIN,15));

        JMenuItem logout = new JMenuItem("Log Out");
        logout.setFont(new Font("monospaced",Font.PLAIN,14));
        ImageIcon ex = new ImageIcon(ClassLoader.getSystemResource("icons/exit.png"));
        Image exi = ex.getImage().getScaledInstance(24,24,SCALE_DEFAULT);
        logout.setIcon(new ImageIcon(exi));
        logout.addActionListener(this);
        exit.add(logout);

        if(acctype.equals("Admin")){
            menuBar.add(menu);
        }
        else{
            menuBar.add(bill);
            menuBar.add(user);
            menuBar.add(info);
        }

        menuBar.add(utility);
        menuBar.add(exit);

        setLayout(new FlowLayout());
        setVisible(true);
    }

    public static void main(String[] args) {
        new Main_class("","");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String msg = e.getActionCommand();
        if(msg.equals("New Customer")){
            new NewCustomer();
        }
        else if(msg.equals("Customer Details")){
            new Customers_details();
        }
        else if(msg.equals("Deposit Details")){
            new Deposit_details();
        }
        else if(msg.equals("Calculate Bill")){
            new Calculate_bill();
        }
        else if(msg.equals("Update Information")){
            new Update_information(meter_pass);
        }
        else if(msg.equals("View Information")){
            new View_information(meter_pass);
        }
        else if(msg.equals("Bill Details")){
            new Bill_details(meter_pass);
        }
        else if(msg.equals("Calculator")){
            try{
                Runtime.getRuntime().exec("calc.exe");
            }
            catch(Exception E){
                E.printStackTrace();
            }
        }
        else if(msg.equals("Notepad")){
            try{
                Runtime.getRuntime().exec("notepad.exe");
            }
            catch(Exception E){
                E.printStackTrace();
            }
        }
        else if(msg.equals("Log Out")){
            setVisible(false);
            new Login();
        }
        else if(msg.equals("Pay Bill")){
            new Pay_bill(meter_pass);
        }
        else if(msg.equals("Generate Bill")){
            new GenerateBill(meter_pass);
        }
    }
}

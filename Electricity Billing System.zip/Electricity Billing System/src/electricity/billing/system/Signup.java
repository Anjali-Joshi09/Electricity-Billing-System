package electricity.billing.system;

import javax.swing.*;
import javax.xml.transform.Result;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.DataBufferShort;
import java.sql.ResultSet;

import static java.awt.Image.SCALE_DEFAULT;

public class Signup extends JFrame implements ActionListener{
    JLabel createAccount, createAccountas, empId, meterNo, userName, name, password,imageLabel;
    JTextField idText, meterText, usernameText, nameText, passwordText;
    Choice accountChoice;
    JButton createbtn, backbtn;
    Signup(){
        super("Sign Up");
        getContentPane().setBackground(new Color(203, 203, 255));
        setSize(600,400);
        setLocation(350,100);
        setLayout(null);
        createAccount = new JLabel("Create-Account");
        createAccount.setBounds(3,0,200,30);
        add(createAccount);

        createAccountas = new JLabel("Create Account As");
        createAccountas.setBounds(40,60,120,30);
        add(createAccountas);
        accountChoice = new Choice();
        accountChoice.add("Admin");
        accountChoice.add("Customer");
        accountChoice.setBounds(180,65,150,30);
        add(accountChoice);

        empId = new JLabel("Employee Id");
        empId.setBounds(40,100,150,30);
        add(empId);
        idText = new JTextField();
        idText.setBounds(180,105,150,23);
        add(idText);
        empId.setVisible((true));
        idText.setVisible((true));

        meterNo = new JLabel("Meter No.");
        meterNo.setBounds(40,100,150,30);
        add(meterNo);
        meterText = new JTextField();
        meterText.setBounds(180,105,150,23);
        add(meterText);
        meterNo.setVisible((false));
        meterText.setVisible((false));

        userName = new JLabel("Username");
        userName.setBounds(40,144,150,30);
        add(userName);
        usernameText = new JTextField();
        usernameText.setBounds(180,150,150,23);
        add(usernameText);

        name = new JLabel("Name");
        name.setBounds(40,192,150,30);
        add(name);
        nameText = new JTextField("");
        nameText.setBounds(180,195,150,23);
        add(nameText);

        meterText.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {

            }

            @Override
            public void focusLost(FocusEvent e) {
                try{
                    Database d = new Database();
                    ResultSet resultSet = d.statement.executeQuery("select * from Signup where meter_no = '"+meterText.getText()+"'");
                    if(resultSet.next()){
                        nameText.setText(resultSet.getString("name"));
                    }
                }
                catch(Exception E){
                    E.printStackTrace();
                }
            }
        });

        password = new JLabel("Password");
        password.setBounds(40,237,150,30);
        add(password);
        passwordText = new JTextField();
        passwordText.setBounds(180,240,150,23);
        add(passwordText);

        createbtn = new JButton("Create");
        createbtn.setBounds(40,290,130,25);
        createbtn.setBackground(new Color(142, 30, 247));
        createbtn.setForeground(Color.white);
        add(createbtn);
        createbtn.addActionListener(this);

        backbtn = new JButton("Back");
        backbtn.setBounds(199,290,130,25);
        backbtn.setBackground(new Color(142, 30, 247));
        backbtn.setForeground(Color.white);
        add(backbtn);
        backbtn.addActionListener(this);

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/signupicon.jpg"));
        imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(350,62,220,252);
        add(imageLabel);
        accountChoice.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                String user = accountChoice.getSelectedItem();
                if(user.equals("Customer")){
                    empId.setVisible(false);
                    nameText.setEditable(false);
                    idText.setVisible((false));
                    meterNo.setVisible(true);
                    meterText.setVisible(true);
                }
                else{
                    empId.setVisible(true);
                    idText.setVisible((true));
                    meterNo.setVisible(false);
                    meterText.setVisible(false);
                }
            }
        });

        setVisible(true);
    }
    public static void main(String[] args) {
        new Signup();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==backbtn){
            setVisible(false);
            new Login();
        }
        else if(e.getSource()==createbtn){
            String susertype = accountChoice.getSelectedItem();
            String Employee_Id = idText.getText();
            String susername = usernameText.getText();
            String sname = nameText.getText();
            String spassword = passwordText.getText();
            String smeter = meterText.getText();

            try{
                Database d = new Database();
                String query = null;
                if(susertype.equals("Admin")) {
                    query = "insert into Signup value('"+smeter+"','"+Employee_Id+"','"+susername+"','"+sname+"','"+spassword+"','"+susertype+"')";
                }
                else {
                    query = "update Signup set username = '"+susername+"',password = '"+spassword+"',usertype = '"+susertype+"' where meter_no = '"+smeter+"'";
                }
                d.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null ,"Account Created..");
                setVisible(false);
                new Login();
            }
            catch(Exception ae){
                ae.printStackTrace();
            }
            setVisible(false);
        }
    }
}

package electricity.billing.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;

public class Pay_bill extends JFrame implements ActionListener {
    String meter;
    JLabel heading;
    JButton pay,back;
    Choice monthcho;
    Pay_bill(String meter){
        super("Pay Bill");
        this.meter = meter;
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(255, 147, 190));

        heading = new JLabel("Pay Bill");
        heading.setBounds(200,15,200,50);
        heading.setFont(new Font("Tahoma",Font.BOLD,24));
        heading.setForeground(Color.WHITE);
        add(heading);

        JLabel meterno = new JLabel("Meter Number");
        meterno.setBounds(80,80,110,50);
        meterno.setFont(new Font("Tahoma",Font.BOLD,13));
        add(meterno);

        JLabel metertext = new JLabel("");
        metertext.setBounds(250,80,110,50);
        metertext.setFont(new Font("Tahoma",Font.BOLD,13));
        add(metertext);

        JLabel name = new JLabel("Name");
        name.setBounds(80,130,110,50);
        name.setFont(new Font("Tahoma",Font.BOLD,13));
        add(name);

        JLabel nametext = new JLabel("");
        nametext.setBounds(250,130,110,50);
        nametext.setFont(new Font("Tahoma",Font.BOLD,13));
        add(nametext);

        JLabel month = new JLabel("Month");
        month.setBounds(80,180,110,50);
        month.setFont(new Font("Tahoma",Font.BOLD,13));
        add(month);

        monthcho = new Choice();
        monthcho.setBounds(250,193,150,25);
        monthcho.add("January");
        monthcho.add("February");
        monthcho.add("March");
        monthcho.add("April");
        monthcho.add("May");
        monthcho.add("June");
        monthcho.add("July");
        monthcho.add("August");
        monthcho.add("September");
        monthcho.add("October");
        monthcho.add("November");
        monthcho.add("December");
        add(monthcho);

        JLabel unit = new JLabel("Unit");
        unit.setBounds(80,230,110,50);
        unit.setFont(new Font("Tahoma",Font.BOLD,13));
        add(unit);

        JLabel unittext = new JLabel("");
        unittext.setBounds(250,230,110,50);
        unittext.setFont(new Font("Tahoma",Font.BOLD,13));
        add(unittext);

        JLabel bill = new JLabel("Total Bill");
        bill.setBounds(80,280,110,50);
        bill.setFont(new Font("Tahoma",Font.BOLD,13));
        add(bill);

        JLabel billtext = new JLabel("");
        billtext.setBounds(250,280,110,50);
        billtext.setFont(new Font("Tahoma",Font.BOLD,13));
        add(billtext);

        JLabel status = new JLabel("Status");
        status.setBounds(80,330,110,50);
        status.setFont(new Font("Tahoma",Font.BOLD,13));
        add(status);

        JLabel statustext = new JLabel("");
        statustext.setBounds(250,330,110,50);
        statustext.setFont(new Font("Tahoma",Font.BOLD,13));
        statustext.setForeground(Color.BLUE);
        add(statustext);

        try{
            Database d = new Database();
            ResultSet resultSet = d.statement.executeQuery("select * from NewCustomer where meter_no = '"+meter+"'");
            while(resultSet.next()){
                metertext.setText(meter);
                nametext.setText(resultSet.getString("name"));
            }

        }
        catch(Exception e){
            e.printStackTrace();
        }
        monthcho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                Database d = new Database();
                try{
                    ResultSet resultSet = d.statement.executeQuery("select * from Bill where meter_no = '"+meter+"' and month = '"+monthcho.getSelectedItem()+"'");
                    while(resultSet.next()){
                        unittext.setText(resultSet.getString("unit"));
                        billtext.setText(resultSet.getString("total_bill"));
                        statustext.setText(resultSet.getString("status"));
                    }
                }
                catch(Exception E){
                    E.printStackTrace();
                }
            }
        });

        pay = new JButton("Pay");
        pay.setBounds(100,400,120,25);
        pay.setForeground(Color.WHITE);
        pay.setBackground(Color.BLACK);
        pay.addActionListener(this);
        add(pay);

        back = new JButton("Back");
        back.setBounds(260,400,120,25);
        back.setForeground(Color.WHITE);
        back.setBackground(Color.BLACK);
        back.addActionListener(this);
        add(back);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==pay){
            try{
                Database d = new Database();
                d.statement.executeUpdate("update Bill set status = 'Paid' where meter_no = '"+meter+"' and month = '"+monthcho.getSelectedItem()+"'");
            }
            catch(Exception ee){
                ee.printStackTrace();
            }
            setVisible(false);
            new Payment(meter);
        }
        else{
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Pay_bill("");
    }
}

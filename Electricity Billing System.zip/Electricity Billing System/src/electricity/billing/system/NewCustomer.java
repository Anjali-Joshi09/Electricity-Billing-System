package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.concurrent.ExecutionException;

public class NewCustomer extends JFrame implements ActionListener {
    JLabel newCustHeading, newCust,meterText, meterNo, address, city,state,email,phone,imageLabel;
    JTextField newCustText,addressText,cityText,stateText,emailText,phoneText;
    JButton nextbtn,cancelbtn;
    NewCustomer(){
        super("New Customer");
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(255, 187, 157));

        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/customer.png"));
        imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(20, 101, 200, 250);
        add(imageLabel);

        newCustHeading = new JLabel("New Customer");
        newCustHeading.setBounds(310,15,150,50);
        newCustHeading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(newCustHeading);

        newCust = new JLabel("New Customer ");
        newCust.setBounds(250,80,110,50);
        newCust.setFont(new Font("Tahoma",Font.BOLD,13));
        add(newCust);
        newCustText = new JTextField();
        newCustText.setBounds(380,90,150,25);
        add(newCustText);

        meterNo = new JLabel("Meter No.");
        meterNo.setBounds(250,120,110,50);
        meterNo.setFont(new Font("Tahoma",Font.BOLD,13));
        add(meterNo);
        meterText = new JLabel();
        meterText.setBounds(380,130,150,25);
        add(meterText);
        Random ran = new Random();
        long number = ran.nextLong() % 1000000;
        meterText.setText(""+Math.abs(number));

        address = new JLabel("Address ");
        address.setBounds(250,160,110,50);
        address.setFont(new Font("Tahoma",Font.BOLD,13));
        add(address);
        addressText = new JTextField();
        addressText.setBounds(380,170,150,25);
        add(addressText);

        city = new JLabel("City ");
        city.setBounds(250,200,110,50);
        city.setFont(new Font("Tahoma",Font.BOLD,13));
        add(city);
        cityText = new JTextField();
        cityText.setBounds(380,210,150,25);
        add(cityText);

        state = new JLabel("State");
        state.setBounds(250,240,110,50);
        state.setFont(new Font("Tahoma",Font.BOLD,13));
        add(state);
        stateText = new JTextField();
        stateText.setBounds(380,250,150,25);
        add(stateText);

        email = new JLabel("Email");
        email.setBounds(250,280,110,50);
        email.setFont(new Font("Tahoma",Font.BOLD,13));
        add(email);
        emailText = new JTextField();
        emailText.setBounds(380,290,150,25);
        add(emailText);

        phone = new JLabel("Phone No.");
        phone.setBounds(250,320,110,50);
        phone.setFont(new Font("Tahoma",Font.BOLD,13));
        add(phone);
        phoneText = new JTextField();
        phoneText.setBounds(380,330,150,25);
        add(phoneText);

        nextbtn = new JButton("Next");
        nextbtn.setBounds(250,385,130,25);
        add(nextbtn);
        nextbtn.addActionListener(this);

        cancelbtn = new JButton("Cancel");
        cancelbtn.setBounds(400,385,130,25);
        add(cancelbtn);
        cancelbtn.addActionListener(this);

        setVisible(true);
    }

    public static void main(String[] args) {
        new NewCustomer();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==nextbtn)
        {
            String sname = newCustText.getText();
            String smeter = meterText.getText();
            String saddress = addressText.getText();
            String scity = cityText.getText();
            String sstate = stateText.getText();
            String semail = emailText.getText();
            String sphone = phoneText.getText();
            String susertype="Customer";

            try{
                String query_customer = "insert into NewCustomer value('"+sname+"','"+smeter+"','"+saddress+"','"+scity+"','"+sstate+"','"+semail+"','"+sphone+"')";
                String query_Signup = "insert into Signup value('"+smeter+"','','','"+sname+"','','"+susertype+"')";
                Database d = new Database();
                d.statement.executeUpdate(query_customer);
                JOptionPane.showMessageDialog(null,"Customer details added successfully");
                d.statement.executeUpdate(query_Signup);
                System.out.println("Data inserted");
                setVisible(false);
                new Meter_info(smeter);
            }
            catch(Exception E) {
                E.printStackTrace();
            }
        }
        if(e.getSource()==cancelbtn)
        {
            setVisible(false);
        }
    }
}

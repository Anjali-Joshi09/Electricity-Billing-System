package electricity.billing.system;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Payment extends JFrame implements ActionListener {
    JButton back;
    String meter;
    Payment(String meter){
        this.meter = meter;
        JEditorPane j = new JEditorPane();
        j.setEditable(false);

        try{
            j.setPage("https://paytm.com/online-payments");
            j.setBounds(400,150,800,600);
        }
        catch(Exception e){
            e.printStackTrace();
            j.setContentType("text/html");
            j.setText("<html>Error! Error! Error! Error! Error!");
        }
        JScrollPane pane = new JScrollPane(j);
        add(pane);

        back = new JButton();
        back.setBounds(500,20,80,30);
        back.addActionListener(this);

        setSize(800,600);
        setLocation(250,20);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Payment("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
        new Pay_bill(meter);
    }
}

package electricity.billing.system;
import javax.swing.*;
import java.awt.*;
import static java.awt.Image.SCALE_DEFAULT;
public class Splash extends JFrame{
    Splash()
    {
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/splash.jpg"));
        Image imageSet = imageIcon.getImage().getScaledInstance(1366,600,SCALE_DEFAULT);
        ImageIcon imageIcon2 = new ImageIcon(imageSet);
        JLabel imageLabel = new JLabel(imageIcon2);
        add(imageLabel);
        setSize(550,450);
        setLocation(370,130);
        setVisible(true);
        try{
            Thread.sleep(3000);
            setVisible(false);
            new Login();
        }
        catch(Exception e) {
            e.printStackTrace();
            System.out.println(e);
        }
    }
    public static void main(String[] args){

        new Splash();
    }
}

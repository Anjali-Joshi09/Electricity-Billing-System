package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Update_information extends JFrame implements ActionListener {
    JLabel meterHeading,nameLabel,meterLabel,name,meterno,state,email,phone,city,address;
    JTextField addresstext,citytext,statetext,emailtext,phonetext;
    String meter;
    JButton update, cancel;
    Update_information(String meter){
        super("Update Information");
        this.meter = meter;
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(117, 252, 164));

        meterHeading = new JLabel("Update Information");
        meterHeading.setBounds(110,15,200,50);
        meterHeading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(meterHeading);

        name = new JLabel("Name");
        name.setBounds(50,70,70,50);
        name.setFont(new Font("Tahoma",Font.BOLD,13));
        add(name);
        nameLabel = new JLabel("");
        nameLabel.setBounds(220,82,150,25);
        add(nameLabel);

        meterno = new JLabel("Meter Number");
        meterno.setBounds(50,110,100,50);
        meterno.setFont(new Font("Tahoma",Font.BOLD,13));
        add(meterno);
        meterLabel = new JLabel("");
        meterLabel.setBounds(220,122,150,25);
        add(meterLabel);

        address = new JLabel("Address");
        address.setBounds(50,150,100,50);
        address.setFont(new Font("Tahoma",Font.BOLD,13));
        add(address);
        addresstext = new JTextField("");
        addresstext.setBounds(220,162,150,25);
        add(addresstext);

        city = new JLabel("City");
        city.setBounds(50,190,100,50);
        city.setFont(new Font("Tahoma",Font.BOLD,13));
        add(city);
        citytext = new JTextField("");
        citytext.setBounds(220,202,150,25);
        add(citytext);

        state = new JLabel("State");
        state.setBounds(50,240,100,50);
        state.setFont(new Font("Tahoma",Font.BOLD,13));
        add(state);
        statetext = new JTextField("");
        statetext.setBounds(220,252,150,25);
        add(statetext);

        email = new JLabel("Email Id");
        email.setBounds(50,290,100,50);
        email.setFont(new Font("Tahoma",Font.BOLD,13));
        add(email);
        emailtext = new JTextField("");
        emailtext.setBounds(220,302,150,25);
        add(emailtext);


        phone = new JLabel("Phone No");
        phone.setBounds(50,330,100,50);
        phone.setFont(new Font("Tahoma",Font.BOLD,13));
        add(phone);
        phonetext = new JTextField("");
        phonetext.setBounds(220,342,150,25);
        add(phonetext);

        try{
            Database d = new Database();
            ResultSet resultSet = d.statement.executeQuery("select * from NewCustomer where meter_no = '"+meter+"'");
            if(resultSet.next()){
                nameLabel.setText((resultSet.getString("name")));
                meterLabel.setText((resultSet.getString("meter_no")));
                addresstext.setText((resultSet.getString("address")));
                citytext.setText((resultSet.getString("city")));
                statetext.setText((resultSet.getString("state")));
                emailtext.setText((resultSet.getString("email")));
                phonetext.setText((resultSet.getString("phone_no")));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        update = new JButton("Update");
        update.setBackground(Color.WHITE);
        update.setBounds(60,405,120,20);
        update.addActionListener(this);
        add(update);

        cancel = new JButton("Close");
        cancel.setBackground(Color.WHITE);
        cancel.setBounds(220,405,120,20);
        cancel.addActionListener(this);
        add(cancel);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==update){
            String saddress = addresstext.getText();
            String scity = citytext.getText();
            String sstate = statetext.getText();
            String semail = emailtext.getText();
            String sphone = phonetext.getText();
            try{
                Database d = new Database();
                d.statement.executeUpdate("update NewCustomer set address = '"+saddress+"',city = '"+scity+"',state = '"+sstate+"',email = '"+semail+"',phone_no='"+sphone+"' where meter_no = '"+meter+"'");
                JOptionPane.showMessageDialog(null,"Information Updated successfully");
            }
            catch(Exception E)
            {
                E.printStackTrace();
            }
        }
        else{
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Update_information("");
    }
}

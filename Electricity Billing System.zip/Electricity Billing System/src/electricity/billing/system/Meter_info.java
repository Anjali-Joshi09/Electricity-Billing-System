package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Meter_info extends JFrame implements ActionListener {
    JLabel meterHeading,meterNo,meter,choiceLabel,phasecode,location,billType,day,note,note1;
    Choice locationcho,meterCho,phasecho,billcho;
    JButton submit;
    String meterNumber;

    Meter_info(String meterNumber){
        super("Meter Info");
        this.meterNumber = meterNumber;
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(255, 187, 157));

        meterHeading = new JLabel("Meter Information");
        meterHeading.setBounds(70,15,200,50);
        meterHeading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(meterHeading);

        meterNo = new JLabel("Meter Number");
        meterNo.setBounds(40,80,100,50);
        add(meterNo);
        meter = new JLabel(meterNumber);
        meter.setBounds(150,90,150,25);
        add(meter);

        location = new JLabel("Meter Number");
        location.setBounds(40,125,100,50);
        add(location);
        locationcho = new Choice();
        locationcho.setBounds(150,140,150,25);
        locationcho.add("Inside");
        locationcho.add("Outside");
        add(locationcho);

        choiceLabel = new JLabel("Meter type");
        choiceLabel.setBounds(40,165,100,50);
        add(choiceLabel);
        meterCho = new Choice();
        meterCho.setBounds(150,180,150,25);
        meterCho.add("Electric Meter");
        meterCho.add("Solar Meter");
        meterCho.add("Smart Meter");
        add(meterCho);

        phasecode = new JLabel("Phase Code");
        phasecode.setBounds(40,205,100,50);
        add(phasecode);
        phasecho = new Choice();
        phasecho.setBounds(150,220,150,25);
        phasecho.add("011");
        phasecho.add("022");
        phasecho.add("033");
        phasecho.add("044");
        phasecho.add("055");
        phasecho.add("066");
        phasecho.add("077");
        phasecho.add("088");
        phasecho.add("099");
        add(phasecho);

        billType = new JLabel("Bill type");
        billType.setBounds(40,245,100,50);
        add(billType);
        billcho = new Choice();
        billcho.setBounds(150,260,150,25);
        billcho.add("Normal");
        billcho.add("Industrial");
        add(billcho);

        day = new JLabel("30 Days Billing Time...");
        day.setBounds(40,290,150,50);
        add(day);

        note = new JLabel("Note:-");
        note.setBounds(40,330,100,50);
        add(note);

        note1 = new JLabel("By default bill is calculated for 30 days only");
        note1.setBounds(40,350,280,50);
        add(note1);

        submit = new JButton("Submit");
        submit.setBounds(200,410,100,25);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        add(submit);
        submit.addActionListener(this);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Meter_info("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==submit)
        {
            String smeterNum = meterNumber;
            String sloc = locationcho.getSelectedItem();
            String smeter= meterCho.getSelectedItem();
            String sphase = phasecho.getSelectedItem();
            String sbill = billcho.getSelectedItem();
            String sday = "30";
            String query = "insert into Meter_info value('"+smeterNum+"','"+sloc+"','"+smeter+"','"+sphase+"','"+sbill+"','"+sday+"')";
            try{
                Database d= new Database();
                d.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"Meter information submitted successfully");
                setVisible(false);
            }
            catch(Exception E){
                E.printStackTrace();
            }
        }
    }
}

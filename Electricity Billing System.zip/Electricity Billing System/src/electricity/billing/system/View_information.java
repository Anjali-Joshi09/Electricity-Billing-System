package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class View_information extends JFrame implements ActionListener
{
    String view;
    JLabel meterHeading,name,nameLabel,meter,meterLabel,address,addressLabel,city,cityLabel,stateLabel,state,email,emailLabel,phone,phoneLabel;
    JButton cancel;
    View_information(String view)
    {
        super("View Information");
        this.view = view;
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(117, 252, 164));

        meterHeading = new JLabel("View Information");
        meterHeading.setBounds(70,15,200,50);
        meterHeading.setFont(new Font("Tahoma",Font.BOLD,20));
        add(meterHeading);

        name = new JLabel("Name");
        name.setBounds(50,70,70,50);
        name.setFont(new Font("Tahoma",Font.BOLD,13));
        add(name);
        nameLabel = new JLabel("");
        nameLabel.setBounds(220,82,150,25);
        add(nameLabel);

        meter = new JLabel("Meter Number");
        meter.setBounds(50,110,100,50);
        meter.setFont(new Font("Tahoma",Font.BOLD,13));
        add(meter);
        meterLabel = new JLabel("");
        meterLabel.setBounds(220,122,150,25);
        add(meterLabel);

        address = new JLabel("Address");
        address.setBounds(50,150,100,50);
        address.setFont(new Font("Tahoma",Font.BOLD,13));
        add(address);
        addressLabel = new JLabel("");
        addressLabel.setBounds(220,162,150,25);
        add(addressLabel);

        city = new JLabel("City");
        city.setBounds(50,190,100,50);
        city.setFont(new Font("Tahoma",Font.BOLD,13));
        add(city);
        cityLabel = new JLabel("");
        cityLabel.setBounds(220,202,150,25);
        add(cityLabel);

        state = new JLabel("State");
        state.setBounds(50,240,100,50);
        state.setFont(new Font("Tahoma",Font.BOLD,13));
        add(state);
        stateLabel = new JLabel("");
        stateLabel.setBounds(220,252,150,25);
        add(stateLabel);

        email = new JLabel("Email Id");
        email.setBounds(50,290,100,50);
        email.setFont(new Font("Tahoma",Font.BOLD,13));
        add(email);
        emailLabel = new JLabel("");
        emailLabel.setBounds(220,302,150,25);
        add(emailLabel);


        phone = new JLabel("Phone No");
        phone.setBounds(50,330,100,50);
        phone.setFont(new Font("Tahoma",Font.BOLD,13));
        add(phone);
        phoneLabel = new JLabel("");
        phoneLabel.setBounds(220,342,150,25);
        add(phoneLabel);

        try{
            Database d = new Database();
            ResultSet resultSet = d.statement.executeQuery("select * from NewCustomer where meter_no = '"+view+"'");
            if(resultSet.next()){
                nameLabel.setText(resultSet.getString("name"));
                meterLabel.setText(resultSet.getString("meter_no"));
                addressLabel.setText(resultSet.getString("address"));
                cityLabel.setText(resultSet.getString("city"));
                stateLabel.setText(resultSet.getString("state"));
                emailLabel.setText(resultSet.getString("email"));
                phoneLabel.setText(resultSet.getString("phone_no"));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        cancel = new JButton("Close");
        cancel.setBackground(Color.WHITE);
        cancel.setBounds(120,400,80,20);
        cancel.addActionListener(this);
        add(cancel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new View_information("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancel) {
            setVisible(false);
        }
    }
}

package electricity.billing.system;
import javax.swing.*;
import javax.xml.crypto.Data;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener {
    JTextField usertext, passwordtext;
    JLabel imageLabel, username, password, loginas;
    JButton loginbtn, cancelbtn, signupbtn;
    Choice loginchoice;

    Login() {
        super("Login");
        getContentPane().setBackground(new Color(115, 207, 240));
        setSize(600, 300);
        setLocation(350, 170);
        setLayout(null);
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("icons/usericon.jpg"));
        imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(40, 15, 200, 220);
        add(imageLabel);
        username = new JLabel("Username");
        username.setBounds(300, 10, 110, 40);
        add(username);
        usertext = new JTextField();
        usertext.setBounds(400, 20, 150, 25);
        add(usertext);

        password = new JLabel("Password");
        password.setBounds(300, 52, 110, 40);
        add(password);
        passwordtext = new JTextField();
        passwordtext.setBounds(400, 60, 150, 25);
        add(passwordtext);

        loginas = new JLabel("Logged in as");
        loginas.setBounds(300, 92, 100, 40);
        add(loginas);
        loginchoice = new Choice();
        loginchoice.add("Admin");
        loginchoice.add("Customer");
        loginchoice.setBounds(400, 100, 150, 40);
        add(loginchoice);

        loginbtn = new JButton("Login");
        loginbtn.setBounds(300, 142, 120, 25);
        loginbtn.addActionListener(this);
        add(loginbtn);

        cancelbtn = new JButton("Cancel");
        cancelbtn.setBounds(430, 142, 120, 25);
        cancelbtn.addActionListener(this);
        add(cancelbtn);

        signupbtn = new JButton("Sign Up");
        signupbtn.setBounds(362, 190, 120, 25);
        signupbtn.addActionListener(this);
        add(signupbtn);


        setVisible(true);
    }

    public static void main(String[] args) {
        new Login();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == signupbtn) {
            setVisible(false);
            new Signup();
        }
        if (e.getSource() == cancelbtn) {
            setVisible(false);
        }
        if (e.getSource() == loginbtn) {
            String susername = usertext.getText();
            String spassword = passwordtext.getText();
            String suser = loginchoice.getSelectedItem();
            try {
                Database d = new Database();
                String query = "select * from Signup where username = '" + susername + "' and password = '" + spassword + "' and usertype = '" + suser + "'";
                ResultSet rs = d.statement.executeQuery(query);
                if (rs.next()) {
                    String meter = rs.getString("meter_no");
                    setVisible(false);
                    new Main_class(suser,meter);
                }
                else {
                    JOptionPane.showMessageDialog(null, "Inavlid Login");
                }
            } catch (Exception ee) {
                ee.printStackTrace();
            }
        }
    }
}

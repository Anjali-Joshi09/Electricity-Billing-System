package electricity.billing.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Deposit_details extends JFrame implements ActionListener {
    JLabel meter,month;
    Choice metercho,monthcho;
    JTable table;
    JButton search,print,close;
    Deposit_details(){
        super("Deposit Details");
        setSize(600,500);
        setLocation(350,100);
        setLayout(null);
        getContentPane().setBackground(new Color(117, 252, 227));

        meter = new JLabel("Meter Number");
        meter.setBounds(30,20,110,50);
        meter.setFont(new Font("Tahoma",Font.BOLD,13));
        add(meter);
        metercho = new Choice();
        metercho.setBounds(140,34,150,25);
        add(metercho);
        try{
            Database d = new Database();
            ResultSet resultSet = d.statement.executeQuery("select * from Bill");
            while(resultSet.next()){
                metercho.add(resultSet.getString("meter_no"));
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        month = new JLabel("Month");
        month.setBounds(350,20,50,50);
        month.setFont(new Font("Tahoma",Font.BOLD,13));
        add(month);
        monthcho = new Choice();
        monthcho.setBounds(400,34,150,25);
        monthcho.add("January");
        monthcho.add("February");
        monthcho.add("March");
        monthcho.add("April");
        monthcho.add("May");
        monthcho.add("June");
        monthcho.add("July");
        monthcho.add("August");
        monthcho.add("September");
        monthcho.add("October");
        monthcho.add("November");
        monthcho.add("December");
        add(monthcho);

        table = new JTable();
        try{
            Database d = new Database();
            ResultSet resultSet = d.statement.executeQuery("select * from Bill");
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }
        catch(Exception e){
            e.printStackTrace();
        }
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0,100,600,500);
        scrollPane.setBackground(Color.WHITE);
        add(scrollPane);

        search = new JButton("Search");
        search.setBackground(Color.WHITE);
        search.setBounds(30,70,80,20);
        search.addActionListener(this);
        add(search);

        print = new JButton("Print");
        print.setBackground(Color.WHITE);
        print.setBounds(130,70,80,20);
        print.addActionListener(this);
        add(print);

        close = new JButton("Close");
        close.setBackground(Color.WHITE);
        close.setBounds(460,70,80,20);
        close.addActionListener(this);
        add(close);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Deposit_details();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == search) {
            String query = "select * from Bill where meter_no = '" + metercho.getSelectedItem() + "' and month ='" + monthcho.getSelectedItem() + "'";
            try {
                Database d = new Database();
                ResultSet resultSet = d.statement.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } catch (Exception E) {
                E.printStackTrace();
            }
        } else if (e.getSource() == print) {
            try {
                table.print();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == close) {
            setVisible(false);
        }
    }
}

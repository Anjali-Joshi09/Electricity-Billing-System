package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class GenerateBill extends JFrame implements ActionListener {
    String meter;
    JTextArea area;
    Choice monthcho;
    JButton bill;
    GenerateBill(String meter){
        this.meter = meter;
        setSize(500,640);
        setLocation(400,30);
        setLayout(new BorderLayout());
        JPanel panel = new JPanel();

        JLabel heading = new JLabel("Generate Bill");
        JLabel meter_no =new JLabel(meter);

        monthcho = new Choice();
        monthcho.add("January");
        monthcho.add("February");
        monthcho.add("March");
        monthcho.add("April");
        monthcho.add("May");
        monthcho.add("June");
        monthcho.add("July");
        monthcho.add("August");
        monthcho.add("September");
        monthcho.add("October");
        monthcho.add("November");
        monthcho.add("December");

        area = new JTextArea(50,15);
        area.setText("\n \n \t...............Click on the .................\n \t....................Generate Bill");
        area.setFont(new Font("Senserif",Font.ITALIC,15));

        JScrollPane pane = new JScrollPane(area);
        bill = new JButton("Generate Bill");
        bill.addActionListener(this);
        add(pane);
        panel.add(heading);
        panel.add(meter_no);
        panel.add(monthcho);
        add(panel,"North");
        add(bill,"South");

        setVisible(true);
    }

    public static void main(String[] args) {
        new GenerateBill("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try{
            Database d = new Database();
            String month = monthcho.getSelectedItem();
            area.setText("\n Power Limited \n Electricity Bill for Month of "+month+",2023\n\n\n");
            ResultSet resultSet = d.statement.executeQuery("select * from NewCustomer where meter_no = '"+meter+"'");
            if(resultSet.next()){
                area.append("\n   Customer Name   :   "+resultSet.getString("name"));
                area.append("\n   Customer Meter Number   :   "+resultSet.getString("meter_no"));
                area.append("\n   Customer Address   :   "+resultSet.getString("address"));
                area.append("\n   Customer City   :   "+resultSet.getString("city"));
                area.append("\n   Customer State   :   "+resultSet.getString("state"));
                area.append("\n   Customer Email   :   "+resultSet.getString("email"));
                area.append("\n   Customer Phone Number   :   "+resultSet.getString("phone_no"));
            }

            resultSet = d.statement.executeQuery("select * from Meter_info where meter_no = '"+meter+"'");
            if(resultSet.next()){
                area.append("\n   Customer Meter Location   :   "+resultSet.getString("meter_location"));
                area.append("\n   Customer Meter Type   :   "+resultSet.getString("meter_type"));
                area.append("\n   Customer Phase Code   :   "+resultSet.getString("phase_code"));
                area.append("\n   Customer Bill Type   :   "+resultSet.getString("bill_type"));
                area.append("\n   Customer Days   :   "+resultSet.getString("days"));
            }

            resultSet = d.statement.executeQuery("select * from Tax");
            if(resultSet.next()){
                area.append("\n   Cost Per Unit   :   "+resultSet.getString("cost_per_unit"));
                area.append("\n   Meter Rent   :   "+resultSet.getString("meter_rent"));
                area.append("\n   Service Charge   :   "+resultSet.getString("service_charge"));
                area.append("\n   Service Tax   :   "+resultSet.getString("service_tax"));
                area.append("\n   Swacch Bharat Tax   :   "+resultSet.getString("swacch_bharat_tax"));
                area.append("\n   Fixed Rent   :   "+resultSet.getString("fixed_tax"));
            }

            resultSet = d.statement.executeQuery("select * from Bill where meter_no = '"+meter+"' and month = '"+monthcho.getSelectedItem()+"'");
            if(resultSet.next()){
                area.append("\n   Current Month   :   "+resultSet.getString("month"));
                area.append("\n   Units Consumed   :   "+resultSet.getString("unit"));
                area.append("\n   Total Charges   :   "+resultSet.getString("total_bill"));
                area.append("\n   Total Payable   :   "+resultSet.getString("total_bill"));
            }
        }
        catch(Exception E){
            E.printStackTrace();;
        }
    }
}

package electricity.billing.system;

import java.sql.*;
import java.util.concurrent.ExecutionException;

public class Database {
    Connection connection;
    Statement statement;
    Database() {
        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Bill_system","root","joshi");
            statement = connection.createStatement();
        }
        catch(Exception e){
            e.printStackTrace();
            System.out.println("Connection failed");
        }
    }

    public static void main(String[] args) {

        new Database();
    }
}
